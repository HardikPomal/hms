import {
  addEntity,
  updateEntity,
  findEntityByNameAndType,
  addRelationship,
  getAllEntities,
  deleteEntity,
} from "../knowledge";

import medicinesData from "../../../data/seed/medicines.json";
import reportsData from "../../../data/seed/reports.json";
import nutritionData from "../../../data/seed/nutrition.json";
import termsData from "../../../data/seed/terms.json";
import cancerInfoData from "../../../data/seed/cancerInfo.json";
import treatmentsData from "../../../data/seed/treatments.json";
import miscData from "../../../data/seed/misc.json";
import relationshipsData from "../../../data/seed/relationships.json";
import labParametersData from "../../../data/seed/labParameters.json";
import hematologyData from "../../../data/seed/hematology.json";
import foodData from "../../../data/seed/food.json";

// ─── Relationships ───────────────────────────────────────────────────────────
const relationships = [
  {
    sourceName: "Ondansetron",
    sourceType: "medication",
    targetName: "Nausea",
    targetType: "general",
    relationType: "improves",
    strength: 90,
  },
  {
    sourceName: "Carboplatin",
    sourceType: "medication",
    targetName: "Neutropenia",
    targetType: "medical_term",
    relationType: "causes",
    strength: 85,
    evidence: "Standard adverse effect of platinum drugs",
  },
  ...relationshipsData,
];

// ─── Seeder ──────────────────────────────────────────────────────────────────

const SEED_VERSION = "v10_food_wipe";
let _seededInMemory = false;

function getRichDescription(item: any) {
  let englishSection = "";
  let gujaratiSection = "";

  if (item.category === "medical_report") {
    englishSection = `<en>\n${item.detailedDescription}\n\n### Why This Report Is Ordered\n- To evaluate overall health and specific organ function\n- To detect or monitor the progression of disease\n- To assess the body's response to ongoing treatments\n- To investigate unexplained symptoms or side effects\n- ${item.whyImportant}\n\n### When It Is Commonly Recommended\n- Before starting a new chemotherapy cycle\n- During routine oncology checkups\n- If experiencing unusual symptoms like fatigue, pain, or fever\n- Post-treatment surveillance for early detection of recurrence\n\n### How To Prepare\n- Follow specific fasting instructions if directed by your oncologist.\n- Drink adequate water unless instructed otherwise.\n- Bring a list of all current medications, including supplements.\n</en>`;
    gujaratiSection = `<gu>\n${item.detailedDescriptionGu || ""}\n\n### આ રિપોર્ટ શા માટે જરૂરી છે\n- ${item.whyImportantGu || ""}\n</gu>`;
  } else if (item.category === "medicine") {
    englishSection = `<en>\n${item.detailedDescription}\n\n### Why This Medicine Is Important\n- ${item.whyImportant}\n- Forms a critical part of the standard treatment protocol.\n</en>`;
    gujaratiSection = `<gu>\n${item.detailedDescriptionGu || ""}\n\n### આ દવા શા માટે મહત્વની છે\n- ${item.whyImportantGu || ""}\n</gu>`;
  } else if (
    item.category === "nutrition" ||
    item.type === "nutrition"
  ) {
    englishSection = `<en>\n${item.detailedDescription || item.simpleMeaning || ""}\n\n### Why This Is Recommended\n- ${item.whyImportant || ""}\n\n### General Advice\n- Discuss any major dietary changes with your oncology team.\n- Remember that individual tolerances may vary during treatment.\n</en>`;
    gujaratiSection = `<gu>\n${item.detailedDescriptionGu || item.simpleMeaningGu || ""}\n\n### આ શા માટે ફાયદાકારક છે\n- ${item.whyImportantGu || ""}\n</gu>`;
  } else {
    englishSection = `<en>\n${item.detailedDescription || item.simpleMeaning || ""}\n\n### Key Takeaways\n- ${item.whyImportant || "Understanding this concept is crucial for making informed medical decisions."}\n</en>`;
    gujaratiSection = `<gu>\n${item.detailedDescriptionGu || item.simpleMeaningGu || ""}\n\n### મુખ્ય બાબતો\n- ${item.whyImportantGu || "આ માહિતી સમજવી સાચી સારવાર પસંદ કરવા માટે ખૂબ જ જરૂરી છે."}\n</gu>`;
  }

  return englishSection + "\n\n" + gujaratiSection;
}

export const seedComprehensiveKnowledge = async () => {
  const storageKey = `seed_done_${SEED_VERSION}`;
  const alreadySeededInStorage =
    typeof window !== "undefined" && localStorage.getItem(storageKey) === "1";

  // Only seed entities if not already done in this session or a previous one
  if (!alreadySeededInStorage && !_seededInMemory) {
    _seededInMemory = true;
    console.log("[KnowledgeDB] Starting comprehensive entity seed...");

    if (SEED_VERSION === "v10_food_wipe") {
      const all = await getAllEntities();
      let wipedCount = 0;
      for (const e of all) {
        if (e.type === "food" || e.type === "nutrition" || e.type === "diet" || e.category === "food" || e.category === "nutrition") {
          await deleteEntity(e.id);
          wipedCount++;
        }
      }
      console.log(`[KnowledgeDB] Wiped ${wipedCount} legacy food/nutrition entities.`);
    }

    const allData = [
      ...medicinesData,
      ...reportsData,
      ...nutritionData,
      ...termsData,
      ...cancerInfoData,
      ...treatmentsData,
      ...miscData,
      ...hematologyData,
      ...foodData,
      ...labParametersData.map((p: any) => ({
        type: "parameter",
        name: p.nameEn,
        nameGu: p.nameGu,
        category: "lab_parameter",
        tags: p.tags || [],
        simpleMeaning: p.descEn || "",
        simpleMeaningGu: p.descGu || "",
        whyImportant: p.whyImportantEn || "",
        alternativeNames: p.akaEn
          ? p.akaEn.split(",").map((s: string) => s.trim())
          : [],
      })),
    ];

    let addedCount = 0;
    let updatedCount = 0;

    for (const item of allData) {
      try {
        const i = item as any;
        const existing = await findEntityByNameAndType(i.name, i.type);
        const richDescription = getRichDescription(item);

        if (!existing) {
          const entityData: any = {
            type: i.type,
            name: i.name,
            nameGu: i.nameGu,
            category: i.category,
            knowledgeStatus: "advanced",
            tags: i.tags || [],
            simpleMeaning: i.simpleMeaning || "",
            simpleMeaningGu: i.simpleMeaningGu || "",
            source: i.source || "Comprehensive Medical DB",
            alternativeNames: i.alternativeNames || [],
          };

          if (i.type === "food") {
            entityData.detailedDescription = i.detailedDescription || "";
            entityData.detailedDescriptionGu = i.detailedDescriptionGu || "";
            entityData.whyImportant = i.whyImportant || "";
            entityData.whyImportantGu = i.whyImportantGu || "";
            entityData.metadata = {
              bestTimeToEat: i.bestTimeToEat || "",
              bestTimeToEatGu: i.bestTimeToEatGu || ""
            };
          } else {
            entityData.detailedDescription = richDescription;
            entityData.whyImportant = i.whyImportantGu
              ? `<en>\n${i.whyImportant || ""}\n</en>\n<gu>\n${i.whyImportantGu}\n</gu>`
              : i.whyImportant || "";
          }

          await addEntity(entityData);
          addedCount++;
        } else if (existing.knowledgeStatus === "advanced") {
          const updateData: any = {
            nameGu: i.nameGu,
            simpleMeaningGu: i.simpleMeaningGu,
            alternativeNames: i.alternativeNames || existing.alternativeNames || [],
          };

          if (i.type === "food") {
            updateData.detailedDescription = i.detailedDescription || "";
            updateData.detailedDescriptionGu = i.detailedDescriptionGu || "";
            updateData.whyImportant = i.whyImportant || "";
            updateData.whyImportantGu = i.whyImportantGu || "";
            updateData.metadata = {
              ...(existing.metadata || {}),
              bestTimeToEat: i.bestTimeToEat || "",
              bestTimeToEatGu: i.bestTimeToEatGu || ""
            };
          } else {
            updateData.detailedDescription = richDescription;
            updateData.whyImportant = i.whyImportantGu
              ? `<en>\n${i.whyImportant || ""}\n</en>\n<gu>\n${i.whyImportantGu}\n</gu>`
              : i.whyImportant || "";
          }

          await updateEntity(existing.id, updateData);
          updatedCount++;
        }
      } catch {
        // skip duplicates or partial errors
      }
    }

    console.log(
      `[KnowledgeDB] Added ${addedCount} new entities and updated ${updatedCount} existing.`,
    );

    if (typeof window !== "undefined") {
      localStorage.setItem(storageKey, "1");
    }
  }

  // ─── ALWAYS rebuild relationship edges ───────────────────────────────────
  // This is fast (idempotent via dedup check in addRelationship) and ensures
  // that even if entities were already in DB from a previous migration (with
  // different IDs), the relationship edges correctly point to them.
  const allEntitiesFromDB = await getAllEntities();
  const entityMap = new Map<string, string>();
  for (const e of allEntitiesFromDB) {
    entityMap.set(`${e.type}::${e.name}`, e.id);
  }

  for (const rel of relationships) {
    const sourceId = entityMap.get(`${rel.sourceType}::${rel.sourceName}`);
    const targetId = entityMap.get(`${rel.targetType}::${rel.targetName}`);

    if (sourceId && targetId) {
      try {
        await addRelationship(
          sourceId,
          rel.sourceType as any,
          targetId,
          rel.targetType as any,
          rel.relationType as any,
          rel.strength,
          (rel as any).evidence,
        );
      } catch {
        // ignore duplicates
      }
    }
  }

  console.log("[KnowledgeDB] Seed + relationship build complete!");
};
